
# 최종 ZIP 파일 생성 (모든 문서 포함)
import zipfile
import os

# ZIP 파일 경로
zip_path = "/tmp/todo-app.zip"
project_root = "/tmp/todo-app"

def zipdir(path, ziph):
    """재귀적으로 디렉토리를 zip 파일에 추가"""
    for root, dirs, files in os.walk(path):
        for file in files:
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, os.path.dirname(path))
            ziph.write(file_path, arcname)

# 기존 ZIP 삭제
if os.path.exists(zip_path):
    os.remove(zip_path)

# 새 ZIP 파일 생성
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    zipdir(project_root, zipf)

# 파일 크기
zip_size = os.path.getsize(zip_path) / (1024 * 1024)

print("\n" + "="*70)
print("✅ 최종 ZIP 파일 생성 완료!")
print("="*70)
print(f"📦 파일명: todo-app.zip")
print(f"📏 파일 크기: {zip_size:.2f} MB")
print(f"📍 저장 위치: {zip_path}")
print("="*70)

# 파일 리스트 출력
with zipfile.ZipFile(zip_path, 'r') as zipf:
    files = sorted(zipf.namelist())
    print(f"\n📊 총 {len(files)}개 파일 포함\n")
    
    print("📚 문서 파일:")
    for f in files:
        if f.endswith('.md'):
            print(f"  ✅ {f}")
    
    print("\n☕ Java 클래스:")
    java_files = [f for f in files if f.endswith('.java')]
    print(f"  총 {len(java_files)}개:")
    for f in sorted(java_files)[:5]:
        print(f"    • {f.split('/')[-1]}")
    if len(java_files) > 5:
        print(f"    ... {len(java_files)-5}개 더")
    
    print("\n🌐 HTML 템플릿:")
    html_files = [f for f in files if f.endswith('.html')]
    for f in sorted(html_files):
        print(f"  ✅ {f.split('/')[-1]}")
    
    print("\n⚙️ 빌드 설정:")
    for f in files:
        if any(x in f for x in ['build.gradle', 'settings.gradle', 'gradle-wrapper.properties']):
            print(f"  ✅ {f.split('/')[-1]}")

print("\n" + "="*70)
print("🎉 프로젝트가 완성되었습니다!")
print("="*70)
print("\n📝 포함된 문서:")
print("  1. README.md - 상세 기술 문서")
print("  2. QUICKSTART.md - 빠른 시작 가이드")
print("  3. PROJECT_SUMMARY.md - 프로젝트 완성 요약")
print("\n💡 다음 단계:")
print("  1. ZIP 파일 다운로드")
print("  2. 압축 해제")
print("  3. IntelliJ에서 열기")
print("  4. MySQL 설정 후 실행")
print("\n" + "="*70)
