
# .gitignore 파일 생성
gitignore = '''# IDE
.idea/
.vscode/
*.iml
*.iws
*.ipr
*.code-workspace

# Build
build/
target/
.gradle/
*.jar
*.war
*.zip

# Environment
.env
.env.local

# OS
.DS_Store
Thumbs.db

# Dependencies
node_modules/
vendor/

# Logs
logs/
*.log

# Database
*.db
*.sqlite
'''

with open(f"{project_root}/.gitignore", "w") as f:
    f.write(gitignore)

print("✓ .gitignore 작성 완료")
