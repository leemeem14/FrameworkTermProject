
# DTO 클래스들

# 1. LoginRequest.java
login_request = '''package com.example.todoapp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.validation.constraints.NotBlank;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LoginRequest {
    @NotBlank(message = "사용자명은 필수입니다")
    private String username;
    
    @NotBlank(message = "비밀번호는 필수입니다")
    private String password;
}
'''

# 2. SignupRequest.java
signup_request = '''package com.example.todoapp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.validation.constraints.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SignupRequest {
    @NotBlank(message = "사용자명은 필수입니다")
    @Size(min = 3, max = 20, message = "사용자명은 3자 이상 20자 이하여야 합니다")
    private String username;
    
    @NotBlank(message = "비밀번호는 필수입니다")
    @Size(min = 6, message = "비밀번호는 최소 6자 이상이어야 합니다")
    private String password;
    
    @NotBlank(message = "비밀번호 확인은 필수입니다")
    private String confirmPassword;
    
    @NotBlank(message = "이메일은 필수입니다")
    @Email(message = "유효한 이메일 주소를 입력하세요")
    private String email;
    
    @NotBlank(message = "이름은 필수입니다")
    private String fullName;
}
'''

# 3. TaskRequest.java
task_request = '''package com.example.todoapp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import jakarta.validation.constraints.NotBlank;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TaskRequest {
    @NotBlank(message = "할일 제목은 필수입니다")
    private String title;
    
    private String description;
    
    private LocalDateTime dueDate;
    
    private Boolean isShared = false;
    
    private Long sharedWithUserId;
}
'''

# 파일 작성
with open(f"{project_root}/src/main/java/com/example/todoapp/dto/LoginRequest.java", "w") as f:
    f.write(login_request)
    
with open(f"{project_root}/src/main/java/com/example/todoapp/dto/SignupRequest.java", "w") as f:
    f.write(signup_request)
    
with open(f"{project_root}/src/main/java/com/example/todoapp/dto/TaskRequest.java", "w") as f:
    f.write(task_request)

print("✓ LoginRequest.java 작성 완료")
print("✓ SignupRequest.java 작성 완료")
print("✓ TaskRequest.java 작성 완료")
