
# 1. build.gradle
build_gradle = '''plugins {
	id 'java'
	id 'org.springframework.boot' version '3.2.0'
	id 'io.spring.dependency-management' version '1.1.4'
}

group = 'com.example'
version = '0.0.1-SNAPSHOT'

java {
	sourceCompatibility = '17'
}

repositories {
	mavenCentral()
}

dependencies {
	// Spring Boot Starter
	implementation 'org.springframework.boot:spring-boot-starter-web'
	implementation 'org.springframework.boot:spring-boot-starter-data-jpa'
	implementation 'org.springframework.boot:spring-boot-starter-thymeleaf'
	implementation 'org.springframework.boot:spring-boot-starter-security'
	
	// MySQL Driver
	runtimeOnly 'com.mysql:mysql-connector-j:8.2.0'
	
	// Lombok
	compileOnly 'org.projectlombok:lombok'
	annotationProcessor 'org.projectlombok:lombok'
	
	// Validation
	implementation 'org.springframework.boot:spring-boot-starter-validation'
	
	// Thymeleaf Security
	implementation 'org.thymeleaf.extras:thymeleaf-extras-springsecurity6'
	
	// Test
	testImplementation 'org.springframework.boot:spring-boot-starter-test'
	testImplementation 'org.springframework.security:spring-security-test'
}

tasks.named('test') {
	useJUnitPlatform()
}
'''

# 2. settings.gradle
settings_gradle = '''rootProject.name = 'todo-app'
'''

# 3. application.yml
application_yml = '''spring:
  application:
    name: todo-app
  
  datasource:
    url: jdbc:mysql://localhost:3306/todo_db?serverTimezone=UTC&characterEncoding=UTF-8
    username: root
    password: root
    driver-class-name: com.mysql.cj.jdbc.Driver
  
  jpa:
    hibernate:
      ddl-auto: update
    show-sql: false
    properties:
      hibernate:
        format_sql: true
        dialect: org.hibernate.dialect.MySQLDialect
    open-in-view: false
  
  logging:
    level:
      root: INFO
      com.example.todoapp: DEBUG
      org.hibernate.SQL: DEBUG
      org.hibernate.type.descriptor.sql.BasicBinder: TRACE

server:
  port: 8080
  servlet:
    context-path: /
'''

# 파일 작성
with open(f"{project_root}/build.gradle", "w") as f:
    f.write(build_gradle)
    
with open(f"{project_root}/settings.gradle", "w") as f:
    f.write(settings_gradle)
    
with open(f"{project_root}/src/main/resources/application.yml", "w") as f:
    f.write(application_yml)

print("✓ build.gradle 작성 완료")
print("✓ settings.gradle 작성 완료")
print("✓ application.yml 작성 완료")
