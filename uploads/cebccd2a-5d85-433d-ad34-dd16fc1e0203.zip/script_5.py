
# Service 클래스들

# 1. UserService.java
user_service = '''package com.example.todoapp.service;

import com.example.todoapp.domain.Role;
import com.example.todoapp.domain.User;
import com.example.todoapp.dto.SignupRequest;
import com.example.todoapp.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class UserService implements UserDetailsService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("사용자를 찾을 수 없습니다: " + username));
    }
    
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }
    
    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }
    
    public User signup(SignupRequest request) {
        if (!request.getPassword().equals(request.getConfirmPassword())) {
            throw new IllegalArgumentException("비밀번호가 일치하지 않습니다");
        }
        
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new IllegalArgumentException("이미 존재하는 사용자명입니다");
        }
        
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new IllegalArgumentException("이미 존재하는 이메일입니다");
        }
        
        User user = User.builder()
                .username(request.getUsername())
                .password(passwordEncoder.encode(request.getPassword()))
                .email(request.getEmail())
                .fullName(request.getFullName())
                .roles(Collections.singleton(createDefaultRole()))
                .build();
        
        return userRepository.save(user);
    }
    
    private Role createDefaultRole() {
        Role role = new Role();
        role.setName("USER");
        return role;
    }
    
    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }
}
'''

# 2. TaskService.java
task_service = '''package com.example.todoapp.service;

import com.example.todoapp.domain.Task;
import com.example.todoapp.domain.User;
import com.example.todoapp.dto.TaskRequest;
import com.example.todoapp.repository.TaskRepository;
import com.example.todoapp.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
@RequiredArgsConstructor
@Slf4j
public class TaskService {
    private final TaskRepository taskRepository;
    private final UserRepository userRepository;
    
    // 사용자의 모든 할일 조회 (개인 + 공유된)
    public List<Task> findAllTasksForUser(User user) {
        List<Task> myTasks = taskRepository.findByUser(user);
        List<Task> sharedTasks = taskRepository.findBySharedWithUser(user);
        myTasks.addAll(sharedTasks);
        return myTasks;
    }
    
    // 개인 할일만 조회
    public List<Task> findMyTasks(User user) {
        return taskRepository.findByUser(user);
    }
    
    // 공유된 할일만 조회
    public List<Task> findSharedWithMe(User user) {
        return taskRepository.findBySharedWithUser(user);
    }
    
    // 할일 생성
    public Task createTask(TaskRequest request, User user) {
        Task task = Task.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .dueDate(request.getDueDate())
                .isShared(request.getIsShared() != null && request.getIsShared())
                .user(user)
                .build();
        
        if (task.getIsShared() && request.getSharedWithUserId() != null) {
            Optional<User> sharedWithUser = userRepository.findById(request.getSharedWithUserId());
            sharedWithUser.ifPresent(task::setSharedWithUser);
        }
        
        return taskRepository.save(task);
    }
    
    // 할일 조회
    public Optional<Task> findTaskById(Long id, User user) {
        return taskRepository.findByIdAndUser(id, user);
    }
    
    // 할일 수정
    public Task updateTask(Long id, TaskRequest request, User user) {
        Task task = taskRepository.findByIdAndUser(id, user)
                .orElseThrow(() -> new IllegalArgumentException("할일을 찾을 수 없습니다"));
        
        task.setTitle(request.getTitle());
        task.setDescription(request.getDescription());
        task.setDueDate(request.getDueDate());
        task.setIsShared(request.getIsShared() != null && request.getIsShared());
        
        if (task.getIsShared() && request.getSharedWithUserId() != null) {
            Optional<User> sharedWithUser = userRepository.findById(request.getSharedWithUserId());
            sharedWithUser.ifPresent(task::setSharedWithUser);
        } else {
            task.setSharedWithUser(null);
        }
        
        return taskRepository.save(task);
    }
    
    // 할일 삭제
    public void deleteTask(Long id, User user) {
        Task task = taskRepository.findByIdAndUser(id, user)
                .orElseThrow(() -> new IllegalArgumentException("할일을 찾을 수 없습니다"));
        taskRepository.delete(task);
    }
    
    // 할일 완료 상태 토글
    public Task toggleTaskCompletion(Long id, User user) {
        Task task = taskRepository.findByIdAndUser(id, user)
                .orElseThrow(() -> new IllegalArgumentException("할일을 찾을 수 없습니다"));
        task.setCompleted(!task.getCompleted());
        return taskRepository.save(task);
    }
}
'''

# 파일 작성
with open(f"{project_root}/src/main/java/com/example/todoapp/service/UserService.java", "w") as f:
    f.write(user_service)
    
with open(f"{project_root}/src/main/java/com/example/todoapp/service/TaskService.java", "w") as f:
    f.write(task_service)

print("✓ UserService.java 작성 완료")
print("✓ TaskService.java 작성 완료")
