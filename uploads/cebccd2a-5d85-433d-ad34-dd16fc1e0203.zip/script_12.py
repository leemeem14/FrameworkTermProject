
# CSS 스타일시트
style_css = '''/* 기본 설정 */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

:root {
    --primary-color: #3498db;
    --secondary-color: #2ecc71;
    --danger-color: #e74c3c;
    --warning-color: #f39c12;
    --light-bg: #ecf0f1;
    --dark-text: #2c3e50;
    --border-color: #bdc3c7;
    --shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    background-color: #f5f5f5;
    color: var(--dark-text);
    line-height: 1.6;
}

/* 네비게이션 바 */
.navbar {
    background-color: var(--primary-color);
    padding: 1rem 0;
    box-shadow: var(--shadow);
    position: sticky;
    top: 0;
    z-index: 100;
}

.navbar-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.navbar-brand a {
    color: white;
    font-size: 1.5rem;
    font-weight: bold;
    text-decoration: none;
}

.navbar-nav {
    display: flex;
    gap: 2rem;
    align-items: center;
}

.navbar-user {
    color: white;
    margin-right: 1rem;
}

/* 버튼 */
.btn {
    display: inline-block;
    padding: 0.6rem 1.2rem;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 1rem;
    text-decoration: none;
    transition: all 0.3s ease;
    text-align: center;
}

.btn-primary {
    background-color: var(--primary-color);
    color: white;
}

.btn-primary:hover {
    background-color: #2980b9;
    transform: translateY(-2px);
    box-shadow: var(--shadow);
}

.btn-secondary {
    background-color: var(--secondary-color);
    color: white;
}

.btn-secondary:hover {
    background-color: #27ae60;
}

.btn-logout {
    background-color: var(--danger-color);
    color: white;
}

.btn-logout:hover {
    background-color: #c0392b;
}

.btn-sm {
    padding: 0.4rem 0.8rem;
    font-size: 0.9rem;
}

.btn-lg {
    padding: 0.8rem 2rem;
    font-size: 1.1rem;
}

.btn-block {
    width: 100%;
}

.btn-edit {
    background-color: var(--primary-color);
    color: white;
}

.btn-edit:hover {
    background-color: #2980b9;
}

.btn-delete {
    background-color: var(--danger-color);
    color: white;
}

.btn-delete:hover {
    background-color: #c0392b;
}

/* 컨테이너 */
.container {
    max-width: 1200px;
    margin: 2rem auto;
    padding: 0 2rem;
}

/* 폼 */
.form-group {
    margin-bottom: 1.5rem;
}

.form-group label {
    display: block;
    margin-bottom: 0.5rem;
    font-weight: 600;
    color: var(--dark-text);
}

.form-control {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid var(--border-color);
    border-radius: 4px;
    font-size: 1rem;
    transition: border-color 0.3s ease;
}

.form-control:focus {
    outline: none;
    border-color: var(--primary-color);
    box-shadow: 0 0 5px rgba(52, 152, 219, 0.3);
}

.form-row {
    display: grid;
    gap: 1rem;
}

@media (min-width: 768px) {
    .form-row {
        grid-template-columns: 1fr 1fr;
    }
}

.checkbox {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.checkbox input {
    width: auto;
    margin: 0;
    cursor: pointer;
}

.checkbox label {
    margin: 0;
    cursor: pointer;
}

.error-message {
    color: var(--danger-color);
    font-size: 0.9rem;
    margin-top: 0.3rem;
}

/* 알림 */
.alert {
    padding: 1rem;
    margin-bottom: 1rem;
    border-radius: 4px;
    border-left: 4px solid;
}

.alert-success {
    background-color: #d4edda;
    color: #155724;
    border-color: #28a745;
}

.alert-error {
    background-color: #f8d7da;
    color: #721c24;
    border-color: #f5c6cb;
}

/* 인증 페이지 */
.auth-container {
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: calc(100vh - 200px);
    padding: 2rem;
}

.auth-card {
    background: white;
    padding: 3rem;
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    width: 100%;
    max-width: 400px;
}

.auth-card h1 {
    text-align: center;
    margin-bottom: 2rem;
    color: var(--primary-color);
}

.auth-form {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.auth-link {
    text-align: center;
    margin-top: 1.5rem;
}

.auth-link a {
    color: var(--primary-color);
    text-decoration: none;
    font-weight: 600;
}

.auth-link a:hover {
    text-decoration: underline;
}

/* 홈페이지 */
.home-container {
    text-align: center;
}

.hero {
    background: linear-gradient(135deg, var(--primary-color), #9b59b6);
    color: white;
    padding: 4rem 2rem;
    border-radius: 8px;
    margin-bottom: 3rem;
}

.hero h1 {
    font-size: 3rem;
    margin-bottom: 1rem;
}

.hero p {
    font-size: 1.2rem;
    margin-bottom: 2rem;
}

.hero-buttons {
    display: flex;
    gap: 1rem;
    justify-content: center;
}

.hero-buttons .btn {
    color: white;
}

.features {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 2rem;
    margin-top: 3rem;
}

.feature {
    background: white;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: var(--shadow);
    transition: transform 0.3s ease;
}

.feature:hover {
    transform: translateY(-5px);
}

.feature h3 {
    color: var(--primary-color);
    margin-bottom: 1rem;
}

/* 할일 페이지 */
.tasks-container {
    background: white;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: var(--shadow);
}

.tasks-container h1 {
    color: var(--primary-color);
    margin-bottom: 2rem;
}

/* 할일 생성 섹션 */
.create-task-section {
    background: var(--light-bg);
    padding: 2rem;
    border-radius: 8px;
    margin-bottom: 2rem;
}

.create-task-section h2 {
    margin-bottom: 1.5rem;
    color: var(--dark-text);
}

.task-form {
    display: grid;
    gap: 1rem;
}

.task-form button {
    justify-self: start;
}

/* 할일 목록 */
.tasks-section {
    margin-bottom: 3rem;
}

.tasks-section h2 {
    color: var(--dark-text);
    margin-bottom: 1.5rem;
    border-bottom: 2px solid var(--primary-color);
    padding-bottom: 0.5rem;
}

.tasks-list {
    display: grid;
    gap: 1rem;
}

.empty-state {
    text-align: center;
    padding: 2rem;
    color: #7f8c8d;
    background: var(--light-bg);
    border-radius: 8px;
}

/* 할일 카드 */
.task-card {
    background: white;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    padding: 1.5rem;
    transition: all 0.3s ease;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
}

.task-card:hover {
    box-shadow: var(--shadow);
    border-color: var(--primary-color);
}

.task-card.completed {
    background-color: #f0f0f0;
    opacity: 0.7;
}

.task-card.completed .task-title {
    text-decoration: line-through;
    color: #95a5a6;
}

.shared-task {
    border-left: 4px solid var(--secondary-color);
    background-color: #f0fdf4;
}

.task-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 1rem;
}

.task-title-section {
    display: flex;
    gap: 1rem;
    flex: 1;
}

.task-checkbox {
    width: 24px;
    height: 24px;
    cursor: pointer;
    margin-top: 0.25rem;
    flex-shrink: 0;
}

.toggle-form {
    display: inline;
}

.task-info {
    flex: 1;
}

.task-title {
    margin: 0;
    color: var(--dark-text);
    font-size: 1.1rem;
}

.task-description {
    margin: 0.5rem 0 0 0;
    color: #7f8c8d;
    font-size: 0.95rem;
}

.task-meta {
    display: flex;
    gap: 1rem;
    margin-top: 0.75rem;
    font-size: 0.9rem;
    flex-wrap: wrap;
}

.task-due-date {
    color: var(--warning-color);
    font-weight: 600;
}

.task-owner {
    color: #7f8c8d;
}

.task-shared {
    display: inline-block;
    background-color: var(--secondary-color);
    color: white;
    padding: 0.25rem 0.75rem;
    border-radius: 20px;
    font-size: 0.85rem;
}

.task-actions {
    display: flex;
    gap: 0.5rem;
    flex-shrink: 0;
}

.delete-form {
    display: inline;
}

/* 수정 페이지 */
.edit-container {
    background: white;
    padding: 2rem;
    border-radius: 8px;
    box-shadow: var(--shadow);
    max-width: 600px;
    margin: 0 auto;
}

.edit-container h1 {
    color: var(--primary-color);
    margin-bottom: 2rem;
}

.task-edit-form {
    display: grid;
    gap: 1.5rem;
}

.form-actions {
    display: flex;
    gap: 1rem;
    margin-top: 2rem;
}

.form-actions .btn {
    flex: 1;
}

/* 반응형 디자인 */
@media (max-width: 768px) {
    .navbar-container {
        flex-direction: column;
        gap: 1rem;
        padding: 1rem;
    }
    
    .navbar-nav {
        flex-direction: column;
        gap: 1rem;
        width: 100%;
    }
    
    .hero h1 {
        font-size: 2rem;
    }
    
    .task-header {
        flex-direction: column;
    }
    
    .task-actions {
        width: 100%;
        margin-top: 1rem;
    }
    
    .hero-buttons {
        flex-direction: column;
    }
    
    .form-row {
        grid-template-columns: 1fr;
    }
}

/* 유틸리티 클래스 */
.text-center {
    text-align: center;
}

.mt-1 { margin-top: 0.5rem; }
.mt-2 { margin-top: 1rem; }
.mt-3 { margin-top: 1.5rem; }
.mt-4 { margin-top: 2rem; }

.mb-1 { margin-bottom: 0.5rem; }
.mb-2 { margin-bottom: 1rem; }
.mb-3 { margin-bottom: 1.5rem; }
.mb-4 { margin-bottom: 2rem; }

.p-1 { padding: 0.5rem; }
.p-2 { padding: 1rem; }
.p-3 { padding: 1.5rem; }
.p-4 { padding: 2rem; }
'''

with open(f"{project_root}/src/main/resources/static/css/style.css", "w", encoding="utf-8") as f:
    f.write(style_css)

print("✓ style.css 작성 완료")
