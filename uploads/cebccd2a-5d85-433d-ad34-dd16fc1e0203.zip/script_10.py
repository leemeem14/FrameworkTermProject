
# 4. tasks.html (메인 할일 목록 페이지)
tasks_html = '''<!DOCTYPE html>
<html xmlns:th="http://www.thymeleaf.org"
      xmlns:sec="http://www.thymeleaf.org/extras/spring-security">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>할일 목록</title>
    <link rel="stylesheet" th:href="@{/css/style.css}">
</head>
<body>
    <div th:insert="fragments/header :: header"></div>
    
    <div class="container tasks-container">
        <h1>내 할일 관리</h1>
        
        <div th:if="${success}" class="alert alert-success" id="successAlert">
            <span th:text="${success}"></span>
        </div>
        
        <div th:if="${error}" class="alert alert-error" id="errorAlert">
            <span th:text="${error}"></span>
        </div>
        
        <!-- 할일 생성 폼 -->
        <div class="create-task-section">
            <h2>새로운 할일 추가</h2>
            <form th:action="@{/tasks}" th:object="${taskRequest}" method="post" class="task-form">
                <div class="form-row">
                    <div class="form-group">
                        <input type="text" th:field="*{title}" class="form-control" 
                               placeholder="할일 제목을 입력하세요" required>
                        <div th:if="${#fields.hasErrors('title')}" class="error-message">
                            <span th:errors="*{title}"></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <textarea th:field="*{description}" class="form-control" 
                                 placeholder="설명 (선택사항)"></textarea>
                    </div>
                    <div class="form-group">
                        <input type="datetime-local" th:field="*{dueDate}" class="form-control" 
                               placeholder="마감날짜 (선택사항)">
                    </div>
                    <div class="form-group checkbox">
                        <input type="checkbox" id="isShared" th:field="*{isShared}">
                        <label for="isShared">다른 사용자와 공유</label>
                    </div>
                    <button type="submit" class="btn btn-primary">추가</button>
                </div>
            </form>
        </div>
        
        <!-- 개인 할일 목록 -->
        <div class="tasks-section">
            <h2>내 할일 (<span th:text="${myTasks.size()}"></span>개)</h2>
            
            <div th:if="${myTasks.isEmpty()}" class="empty-state">
                <p>할일이 없습니다. 새로운 할일을 추가해보세요!</p>
            </div>
            
            <div th:unless="${myTasks.isEmpty()}" class="tasks-list">
                <div th:each="task : ${myTasks}" class="task-card" 
                     th:classappend="${task.completed} ? 'completed' : ''">
                    <div class="task-header">
                        <div class="task-title-section">
                            <form th:action="@{/tasks/{id}/toggle(id=${task.id})}" method="post" class="toggle-form">
                                <input type="checkbox" class="task-checkbox" 
                                       th:checked="${task.completed}" onchange="this.form.submit()">
                            </form>
                            <div class="task-info">
                                <h3 class="task-title" th:text="${task.title}"></h3>
                                <p class="task-description" th:if="${task.description}" 
                                   th:text="${task.description}"></p>
                                <div class="task-meta">
                                    <span th:if="${task.dueDate}" class="task-due-date">
                                        마감: <span th:text="${#temporals.format(task.dueDate, 'yyyy-MM-dd HH:mm')}"></span>
                                    </span>
                                    <span th:if="${task.isShared}" class="task-shared">공유됨</span>
                                </div>
                            </div>
                        </div>
                        <div class="task-actions">
                            <a th:href="@{/tasks/{id}/edit(id=${task.id})}" class="btn btn-sm btn-edit">수정</a>
                            <form th:action="@{/tasks/{id}/delete(id=${task.id})}" method="post" class="delete-form">
                                <button type="submit" class="btn btn-sm btn-delete" 
                                        onclick="return confirm('정말 삭제하시겠습니까?')">삭제</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- 공유된 할일 목록 -->
        <div class="tasks-section" th:if="${not sharedTasks.isEmpty()}">
            <h2>공유된 할일 (<span th:text="${sharedTasks.size()}"></span>개)</h2>
            
            <div class="tasks-list">
                <div th:each="task : ${sharedTasks}" class="task-card shared-task" 
                     th:classappend="${task.completed} ? 'completed' : ''">
                    <div class="task-header">
                        <div class="task-title-section">
                            <div class="task-info">
                                <h3 class="task-title" th:text="${task.title}"></h3>
                                <p class="task-description" th:if="${task.description}" 
                                   th:text="${task.description}"></p>
                                <div class="task-meta">
                                    <span class="task-owner">
                                        작성자: <span th:text="${task.user.fullName}"></span>
                                    </span>
                                    <span th:if="${task.dueDate}" class="task-due-date">
                                        마감: <span th:text="${#temporals.format(task.dueDate, 'yyyy-MM-dd HH:mm')}"></span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // 성공/에러 메시지 자동 삭제
        setTimeout(function() {
            const successAlert = document.getElementById('successAlert');
            const errorAlert = document.getElementById('errorAlert');
            if (successAlert) successAlert.style.display = 'none';
            if (errorAlert) errorAlert.style.display = 'none';
        }, 3000);
    </script>
</body>
</html>
'''

# 5. task-edit.html
task_edit_html = '''<!DOCTYPE html>
<html xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>할일 수정</title>
    <link rel="stylesheet" th:href="@{/css/style.css}">
</head>
<body>
    <div th:insert="fragments/header :: header"></div>
    
    <div class="container edit-container">
        <h1>할일 수정</h1>
        
        <form th:action="@{/tasks/{id}/update(id=${task.id})}" th:object="${taskRequest}" 
              method="post" class="task-edit-form">
            <div class="form-group">
                <label for="title">할일 제목</label>
                <input type="text" id="title" th:field="*{title}" class="form-control" required>
                <div th:if="${#fields.hasErrors('title')}" class="error-message">
                    <span th:errors="*{title}"></span>
                </div>
            </div>
            
            <div class="form-group">
                <label for="description">설명</label>
                <textarea id="description" th:field="*{description}" class="form-control"></textarea>
                <div th:if="${#fields.hasErrors('description')}" class="error-message">
                    <span th:errors="*{description}"></span>
                </div>
            </div>
            
            <div class="form-group">
                <label for="dueDate">마감날짜</label>
                <input type="datetime-local" id="dueDate" th:field="*{dueDate}" class="form-control">
                <div th:if="${#fields.hasErrors('dueDate')}" class="error-message">
                    <span th:errors="*{dueDate}"></span>
                </div>
            </div>
            
            <div class="form-group checkbox">
                <input type="checkbox" id="isShared" th:field="*{isShared}">
                <label for="isShared">다른 사용자와 공유</label>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">저장</button>
                <a th:href="@{/tasks}" class="btn btn-secondary">취소</a>
            </div>
        </form>
    </div>
</body>
</html>
'''

with open(f"{project_root}/src/main/resources/templates/tasks.html", "w", encoding="utf-8") as f:
    f.write(tasks_html)
    
with open(f"{project_root}/src/main/resources/templates/task-edit.html", "w", encoding="utf-8") as f:
    f.write(task_edit_html)

print("✓ tasks.html 작성 완료")
print("✓ task-edit.html 작성 완료")
