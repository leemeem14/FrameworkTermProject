
# 6. index.html (홈페이지)
index_html = '''<!DOCTYPE html>
<html xmlns:th="http://www.thymeleaf.org"
      xmlns:sec="http://www.thymeleaf.org/extras/spring-security">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>할일 관리 앱 - 홈</title>
    <link rel="stylesheet" th:href="@{/css/style.css}">
</head>
<body>
    <div th:insert="fragments/header :: header"></div>
    
    <div class="container home-container">
        <div class="hero">
            <h1>할일 관리 앱</h1>
            <p>효율적으로 당신의 할일을 관리하세요</p>
            
            <div sec:authorize="isAuthenticated()" class="hero-buttons">
                <a th:href="@{/tasks}" class="btn btn-primary btn-lg">내 할일 보기</a>
            </div>
            
            <div sec:authorize="!isAuthenticated()" class="hero-buttons">
                <a th:href="@{/auth/login}" class="btn btn-primary btn-lg">로그인</a>
                <a th:href="@{/auth/signup}" class="btn btn-secondary btn-lg">회원가입</a>
            </div>
        </div>
        
        <div class="features">
            <div class="feature">
                <h3>개인 할일</h3>
                <p>당신의 할일을 개인적으로 관리하세요</p>
            </div>
            <div class="feature">
                <h3>할일 공유</h3>
                <p>다른 사용자와 할일을 공유하세요</p>
            </div>
            <div class="feature">
                <h3>마감날짜</h3>
                <p>각 할일의 마감날짜를 설정하세요</p>
            </div>
            <div class="feature">
                <h3>보안</h3>
                <p>Spring Security로 안전하게 보호됩니다</p>
            </div>
        </div>
    </div>
</body>
</html>
'''

with open(f"{project_root}/src/main/resources/templates/index.html", "w", encoding="utf-8") as f:
    f.write(index_html)

print("✓ index.html 작성 완료")
