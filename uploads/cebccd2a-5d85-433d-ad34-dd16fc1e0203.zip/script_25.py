
# 최종 ZIP 파일 생성 (모든 문서 포함)
import zipfile
import os

zip_path = "/tmp/todo-app.zip"
project_root = "/tmp/todo-app"

def zipdir(path, ziph):
    """재귀적으로 디렉토리를 zip 파일에 추가"""
    for root, dirs, files in os.walk(path):
        for file in files:
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, os.path.dirname(path))
            ziph.write(file_path, arcname)

# 기존 ZIP 삭제
if os.path.exists(zip_path):
    os.remove(zip_path)

# 새 ZIP 파일 생성
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    zipdir(project_root, zipf)

# 최종 정보
zip_size = os.path.getsize(zip_path) / (1024 * 1024)

print("\n" + "="*80)
print(" "*20 + "🎉 프로젝트 완성!")
print("="*80)

with zipfile.ZipFile(zip_path, 'r') as zipf:
    files = zipf.namelist()
    
print(f"\n📦 ZIP 파일 정보")
print(f"  • 파일명: todo-app.zip")
print(f"  • 크기: {zip_size:.2f} MB")
print(f"  • 총 파일 수: {len(files)}")
print(f"  • 위치: /tmp/todo-app.zip")

print(f"\n📚 포함된 문서")
doc_files = [f for f in files if f.endswith('.md')]
for doc in sorted(doc_files):
    doc_name = doc.split('/')[-1]
    print(f"  ✅ {doc_name}")

print(f"\n☕ Java 클래스")
java_files = [f for f in files if f.endswith('.java')]
print(f"  • 총 {len(java_files)}개 클래스")

print(f"\n🌐 웹 리소스")
html_files = [f for f in files if f.endswith('.html')]
css_files = [f for f in files if f.endswith('.css')]
print(f"  • HTML: {len(html_files)}개")
print(f"  • CSS: {len(css_files)}개")

print(f"\n⚙️ 빌드 설정")
print(f"  ✅ build.gradle")
print(f"  ✅ settings.gradle")
print(f"  ✅ Gradle Wrapper")

print(f"\n📖 시작하기")
print(f"  1. todo-app.zip 다운로드")
print(f"  2. 압축 해제")
print(f"  3. IntelliJ에서 'todo-app' 폴더 열기")
print(f"  4. INSTALL_GUIDE.md 따라하기")

print("\n" + "="*80)
print(" "*15 + "✨ Spring Boot 할일 관리 앱 준비 완료! ✨")
print("="*80)
print()

# 다운로드 가능한 상태 확인
print("✅ ZIP 파일이 준비되었습니다!")
print(f"✅ 다운로드 준비: {zip_path}")
print()
