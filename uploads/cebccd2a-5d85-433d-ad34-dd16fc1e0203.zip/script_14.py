
# README.md 작성
readme = '''# 할일 관리 웹 애플리케이션

Spring Boot + Gradle + MySQL + JPA + Thymeleaf + Spring Security를 사용한 완전한 할일 관리 웹 애플리케이션

## 기능

### 1. 사용자 인증
- 회원가입 (username, email, password, fullName)
- 로그인/로그아웃
- Spring Security 기반 인증
- 로그인 유지 기능 (Remember Me)

### 2. 할일 관리
- **개인 할일**: 사용자가 생성한 할일 관리
- **공유 할일**: 다른 사용자와 할일 공유
- **할일 생성**: 제목, 설명, 마감날짜 설정
- **할일 수정**: 기존 할일 정보 수정
- **할일 삭제**: 할일 삭제
- **완료 표시**: 할일 완료 상태 토글

### 3. 데이터 관계
- User와 Task의 JPA 연관관계 설정
- User-Role 다대다 관계
- Task의 주인(user)과 공유 대상(sharedWithUser) 설정

## 기술 스택

- **Framework**: Spring Boot 3.2.0
- **Build Tool**: Gradle (Groovy)
- **Database**: MySQL 8.0+
- **ORM**: Spring Data JPA / Hibernate
- **Template Engine**: Thymeleaf
- **Security**: Spring Security 6
- **Java**: 17+

## 설치 및 실행

### 사전 요구사항

1. **Java 17 이상** 설치
   ```bash
   java -version
   ```

2. **MySQL 8.0+ 설치 및 실행**
   ```bash
   # MySQL 시작 (Windows)
   net start MySQL80
   
   # MySQL 시작 (macOS)
   brew services start mysql
   
   # MySQL 시작 (Linux)
   sudo systemctl start mysql
   ```

3. **데이터베이스 생성**
   ```bash
   mysql -u root -p
   
   # MySQL 명령줄에서
   CREATE DATABASE todo_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```

### 프로젝트 설정

1. **프로젝트 압축 해제**
   ```bash
   unzip todo-app.zip
   cd todo-app
   ```

2. **IntelliJ에서 프로젝트 열기**
   - File → Open → todo-app 폴더 선택
   - Gradle 동기화 대기 (자동으로 진행)

3. **application.yml 설정**
   
   `src/main/resources/application.yml` 파일에서 MySQL 연결 정보 확인:
   
   ```yaml
   spring:
     datasource:
       url: jdbc:mysql://localhost:3306/todo_db?serverTimezone=UTC&characterEncoding=UTF-8
       username: root
       password: root  # 자신의 MySQL 비밀번호로 변경
   ```

### 애플리케이션 실행

#### 방법 1: IntelliJ에서 실행
1. `TodoAppApplication.java` 파일 열기
2. 우측 상단의 녹색 ▶ 버튼 클릭
3. "Run 'TodoAppApplication'" 선택

#### 방법 2: 터미널에서 실행
```bash
./gradlew bootRun
```

#### 방법 3: JAR 빌드 후 실행
```bash
./gradlew build
java -jar build/libs/todo-app-0.0.1-SNAPSHOT.jar
```

## 접속

애플리케이션 실행 후 브라우저에서 다음 주소로 접속:

```
http://localhost:8080
```

## 프로젝트 구조

```
todo-app/
├── src/
│   ├── main/
│   │   ├── java/com/example/todoapp/
│   │   │   ├── TodoAppApplication.java          # 메인 애플리케이션
│   │   │   ├── controller/
│   │   │   │   ├── HomeController.java          # 홈페이지
│   │   │   │   ├── AuthController.java          # 인증 (로그인, 회원가입)
│   │   │   │   └── TaskController.java          # 할일 관리
│   │   │   ├── service/
│   │   │   │   ├── UserService.java             # 사용자 서비스
│   │   │   │   └── TaskService.java             # 할일 서비스
│   │   │   ├── domain/
│   │   │   │   ├── User.java                    # 사용자 엔티티
│   │   │   │   ├── Task.java                    # 할일 엔티티
│   │   │   │   └── Role.java                    # 역할 엔티티
│   │   │   ├── repository/
│   │   │   │   ├── UserRepository.java          # 사용자 저장소
│   │   │   │   └── TaskRepository.java          # 할일 저장소
│   │   │   ├── dto/
│   │   │   │   ├── LoginRequest.java            # 로그인 요청 DTO
│   │   │   │   ├── SignupRequest.java           # 회원가입 요청 DTO
│   │   │   │   └── TaskRequest.java             # 할일 요청 DTO
│   │   │   └── config/
│   │   │       ├── SecurityConfig.java          # Spring Security 설정
│   │   │       └── WebConfig.java               # 웹 설정
│   │   └── resources/
│   │       ├── application.yml                  # 애플리케이션 설정
│   │       ├── templates/                       # Thymeleaf 템플릿
│   │       │   ├── index.html                   # 홈페이지
│   │       │   ├── login.html                   # 로그인 페이지
│   │       │   ├── signup.html                  # 회원가입 페이지
│   │       │   ├── tasks.html                   # 할일 목록 페이지
│   │       │   ├── task-edit.html               # 할일 수정 페이지
│   │       │   └── fragments/
│   │       │       └── header.html              # 헤더 조각
│   │       └── static/
│   │           └── css/
│   │               └── style.css                # 스타일시트
│   └── test/                                    # 테스트 코드
├── build.gradle                                 # Gradle 빌드 설정
├── settings.gradle                              # Gradle 설정
├── gradlew                                      # Gradle Wrapper (Unix)
├── gradlew.bat                                  # Gradle Wrapper (Windows)
└── README.md                                    # 이 파일
```

## 주요 기능 설명

### 엔티티 관계

#### User 엔티티
- 사용자의 기본 정보 (username, email, password, fullName)
- UserDetails 인터페이스 구현으로 Spring Security 통합
- Role과의 다대다 관계

#### Task 엔티티
- 할일의 제목, 설명, 마감날짜
- 완료 상태 (completed)
- 공유 상태 (isShared) 및 공유 대상 (sharedWithUser)
- User와의 다대일 관계

#### Role 엔티티
- 사용자의 권한 관리
- User와의 다대다 관계

### 보안 설정

- **Password Encoding**: BCryptPasswordEncoder 사용
- **Authentication**: UserDetailsService 기반
- **Authorization**: 인증된 사용자만 할일 접근 가능
- **CSRF 보호**: Spring Security 기본 설정

## 데이터베이스 스키마

JPA의 `ddl-auto: update` 설정으로 자동 생성됩니다.

### 생성되는 테이블
- `users`: 사용자 정보
- `tasks`: 할일 정보
- `roles`: 권한 정보
- `user_roles`: 사용자-권한 매핑

## 문제 해결

### MySQL 연결 오류
```
com.mysql.cj.jdbc.exceptions.CommunicationsException: Communications link failure
```

**해결책**:
1. MySQL 서버가 실행 중인지 확인
2. `application.yml`의 연결 정보 확인 (호스트, 포트, 비밀번호)
3. `todo_db` 데이터베이스가 생성되어 있는지 확인

### Gradle 빌드 오류
```
Gradle sync failed
```

**해결책**:
1. IntelliJ 메뉴 → File → Invalidate Caches...
2. IntelliJ 재시작
3. Gradle 재동기화 (View → Tool Windows → Gradle)

### 포트 충돌
기본 포트는 8080입니다. 다른 포트를 사용하려면:

```yaml
# application.yml
server:
  port: 9090  # 원하는 포트 번호
```

## 기능 테스트

### 회원가입
1. 홈페이지에서 "회원가입" 클릭
2. 필수 정보 입력 (username, email, password, fullName)
3. 회원가입 버튼 클릭
4. 로그인 페이지로 리다이렉트

### 로그인
1. 로그인 페이지에서 username/password 입력
2. 로그인 버튼 클릭
3. 할일 목록 페이지로 리다이렉트

### 할일 관리
1. 제목과 설명 입력
2. 마감날짜 설정 (선택사항)
3. 공유 여부 선택
4. "추가" 버튼 클릭
5. 할일 완료, 수정, 삭제 기능 사용 가능

## 향후 개선 사항

- [ ] 할일 우선순위 설정
- [ ] 할일 카테고리/태그 추가
- [ ] 날짜별 할일 필터링
- [ ] 사용자 프로필 페이지
- [ ] 할일 알림 기능
- [ ] REST API 추가
- [ ] Docker 컨테이너화
- [ ] CI/CD 파이프라인

## 라이선스

MIT License

## 개발자 정보

Spring Boot + JPA + Security 기술을 학습하기 위한 샘플 프로젝트입니다.
'''

with open(f"{project_root}/README.md", "w", encoding="utf-8") as f:
    f.write(readme)

print("✓ README.md 작성 완료")
