
# Template files (HTML)

# 1. fragments/header.html
header_html = '''<!DOCTYPE html>
<html xmlns:th="http://www.thymeleaf.org" 
      xmlns:sec="http://www.thymeleaf.org/extras/spring-security">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
    <header th:fragment="header" class="navbar">
        <div class="navbar-container">
            <div class="navbar-brand">
                <a href="/">할일 관리 앱</a>
            </div>
            <nav class="navbar-nav">
                <div sec:authorize="isAuthenticated()">
                    <span class="navbar-user" sec:authentication="name">사용자</span>
                    <a href="/auth/logout" class="btn btn-logout">로그아웃</a>
                </div>
                <div sec:authorize="!isAuthenticated()">
                    <a href="/auth/login" class="btn btn-primary">로그인</a>
                    <a href="/auth/signup" class="btn btn-secondary">회원가입</a>
                </div>
            </nav>
        </div>
    </header>
</body>
</html>
'''

# 2. login.html
login_html = '''<!DOCTYPE html>
<html xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>로그인</title>
    <link rel="stylesheet" th:href="@{/css/style.css}">
</head>
<body>
    <div th:insert="fragments/header :: header"></div>
    
    <div class="container auth-container">
        <div class="auth-card">
            <h1>로그인</h1>
            
            <div th:if="${param.success}" class="alert alert-success">
                회원가입이 완료되었습니다. 로그인하세요.
            </div>
            
            <div th:if="${param.error}" class="alert alert-error">
                로그인에 실패했습니다.
            </div>
            
            <form th:action="@{/auth/login}" method="post" class="auth-form">
                <div class="form-group">
                    <label for="username">사용자명</label>
                    <input type="text" id="username" name="username" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="password">비밀번호</label>
                    <input type="password" id="password" name="password" class="form-control" required>
                </div>
                
                <div class="form-group checkbox">
                    <input type="checkbox" id="rememberMe" name="remember-me">
                    <label for="rememberMe">로그인 유지</label>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">로그인</button>
            </form>
            
            <p class="auth-link">
                계정이 없으신가요? <a th:href="@{/auth/signup}">회원가입</a>
            </p>
        </div>
    </div>
</body>
</html>
'''

# 3. signup.html
signup_html = '''<!DOCTYPE html>
<html xmlns:th="http://www.thymeleaf.org">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>회원가입</title>
    <link rel="stylesheet" th:href="@{/css/style.css}">
</head>
<body>
    <div th:insert="fragments/header :: header"></div>
    
    <div class="container auth-container">
        <div class="auth-card">
            <h1>회원가입</h1>
            
            <div th:if="${error}" class="alert alert-error">
                <span th:text="${error}"></span>
            </div>
            
            <form th:action="@{/auth/signup}" th:object="${signupRequest}" method="post" class="auth-form">
                <div class="form-group">
                    <label for="username">사용자명</label>
                    <input type="text" id="username" th:field="*{username}" class="form-control" required>
                    <div th:if="${#fields.hasErrors('username')}" class="error-message">
                        <span th:errors="*{username}"></span>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="fullName">이름</label>
                    <input type="text" id="fullName" th:field="*{fullName}" class="form-control" required>
                    <div th:if="${#fields.hasErrors('fullName')}" class="error-message">
                        <span th:errors="*{fullName}"></span>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="email">이메일</label>
                    <input type="email" id="email" th:field="*{email}" class="form-control" required>
                    <div th:if="${#fields.hasErrors('email')}" class="error-message">
                        <span th:errors="*{email}"></span>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="password">비밀번호</label>
                    <input type="password" id="password" th:field="*{password}" class="form-control" required>
                    <div th:if="${#fields.hasErrors('password')}" class="error-message">
                        <span th:errors="*{password}"></span>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="confirmPassword">비밀번호 확인</label>
                    <input type="password" id="confirmPassword" th:field="*{confirmPassword}" class="form-control" required>
                    <div th:if="${#fields.hasErrors('confirmPassword')}" class="error-message">
                        <span th:errors="*{confirmPassword}"></span>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">회원가입</button>
            </form>
            
            <p class="auth-link">
                이미 계정이 있으신가요? <a th:href="@{/auth/login}">로그인</a>
            </p>
        </div>
    </div>
</body>
</html>
'''

with open(f"{project_root}/src/main/resources/templates/fragments/header.html", "w", encoding="utf-8") as f:
    f.write(header_html)
    
with open(f"{project_root}/src/main/resources/templates/login.html", "w", encoding="utf-8") as f:
    f.write(login_html)
    
with open(f"{project_root}/src/main/resources/templates/signup.html", "w", encoding="utf-8") as f:
    f.write(signup_html)

print("✓ header.html 작성 완료")
print("✓ login.html 작성 완료")
print("✓ signup.html 작성 완료")
