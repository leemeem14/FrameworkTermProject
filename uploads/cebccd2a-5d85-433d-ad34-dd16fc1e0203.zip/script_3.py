
# Repository 클래스들

# 1. UserRepository.java
user_repo = '''package com.example.todoapp.repository;

import com.example.todoapp.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByUsername(String username);
    Optional<User> findByEmail(String email);
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
}
'''

# 2. TaskRepository.java
task_repo = '''package com.example.todoapp.repository;

import com.example.todoapp.domain.Task;
import com.example.todoapp.domain.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TaskRepository extends JpaRepository<Task, Long> {
    List<Task> findByUser(User user);
    List<Task> findByUserAndIsShared(User user, Boolean isShared);
    List<Task> findBySharedWithUser(User user);
    Optional<Task> findByIdAndUser(Long id, User user);
}
'''

# 파일 작성
with open(f"{project_root}/src/main/java/com/example/todoapp/repository/UserRepository.java", "w") as f:
    f.write(user_repo)
    
with open(f"{project_root}/src/main/java/com/example/todoapp/repository/TaskRepository.java", "w") as f:
    f.write(task_repo)

print("✓ UserRepository.java 작성 완료")
print("✓ TaskRepository.java 작성 완료")
