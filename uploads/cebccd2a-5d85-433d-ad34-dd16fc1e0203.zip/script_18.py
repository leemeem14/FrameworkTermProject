
import zipfile
import os
from pathlib import Path

# ZIP 파일 생성
zip_path = "/tmp/todo-app.zip"
project_root = "/tmp/todo-app"

def zipdir(path, ziph):
    """재귀적으로 디렉토리를 zip 파일에 추가"""
    for root, dirs, files in os.walk(path):
        for file in files:
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, os.path.dirname(path))
            ziph.write(file_path, arcname)

# ZIP 파일 생성
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    zipdir(project_root, zipf)

# 파일 크기 확인
zip_size = os.path.getsize(zip_path) / (1024 * 1024)  # MB

print("=" * 60)
print("ZIP 파일 생성 완료")
print("=" * 60)
print(f"파일 경로: {zip_path}")
print(f"파일 크기: {zip_size:.2f} MB")
print("=" * 60)

# ZIP 파일 내용 확인
print("\nZIP 파일 내용 (샘플):")
with zipfile.ZipFile(zip_path, 'r') as zipf:
    file_list = zipf.namelist()
    print(f"전체 파일 수: {len(file_list)}")
    print("\n주요 파일:")
    for i, file in enumerate(file_list[:15]):
        print(f"  {file}")
    if len(file_list) > 15:
        print(f"  ... {len(file_list) - 15}개 더 있음")
