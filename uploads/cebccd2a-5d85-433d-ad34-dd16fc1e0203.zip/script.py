
import os
import json
import zipfile
from pathlib import Path

# 프로젝트 루트 디렉토리
project_root = "/tmp/todo-app"
os.makedirs(project_root, exist_ok=True)

# 필요한 디렉토리 구조 생성
dirs = [
    "gradle/wrapper",
    "src/main/java/com/example/todoapp/config",
    "src/main/java/com/example/todoapp/domain",
    "src/main/java/com/example/todoapp/repository",
    "src/main/java/com/example/todoapp/service",
    "src/main/java/com/example/todoapp/controller",
    "src/main/java/com/example/todoapp/dto",
    "src/main/resources/static/css",
    "src/main/resources/templates/fragments",
    "src/test/java/com/example/todoapp"
]

for dir_path in dirs:
    full_path = os.path.join(project_root, dir_path)
    os.makedirs(full_path, exist_ok=True)

print(f"✓ 프로젝트 디렉토리 구조 생성 완료: {project_root}")
print(f"✓ 생성된 디렉토리 수: {len(dirs)}")
