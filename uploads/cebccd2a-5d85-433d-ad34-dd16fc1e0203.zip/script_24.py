
# 설치 및 운영 가이드 최종 버전
install_guide = '''# 📖 할일 관리 앱 - 설치 및 운영 완벽 가이드

## 🎯 이 문서의 목적

이 가이드는 다음을 수행하는 방법을 단계별로 설명합니다:
1. ✅ 프로젝트 설치
2. ✅ 데이터베이스 설정
3. ✅ 애플리케이션 실행
4. ✅ 기본 기능 사용
5. ✅ 문제 해결

---

## 📋 사전 준비물 체크리스트

실행하기 전에 다음을 확인하세요:

- [ ] IntelliJ IDEA 또는 다른 Java IDE
- [ ] Java 17 이상
- [ ] MySQL 8.0 이상
- [ ] 최소 500MB 디스크 공간
- [ ] 인터넷 연결 (Gradle 의존성 다운로드)

### 버전 확인 명령어

```bash
# Java 버전 확인 (17 이상이어야 함)
java -version

# MySQL 버전 확인 (8.0 이상이어야 함)
mysql --version
```

---

## 🔧 설치 단계

### Phase 1: 파일 준비 (5분)

#### Step 1-1: ZIP 파일 다운로드
- `todo-app.zip` 파일을 원하는 위치에 다운로드합니다
- 파일 크기: 약 33KB (압축됨)

#### Step 1-2: 압축 해제

**Windows:**
```
파일 탐색기에서 todo-app.zip 우클릭
→ "모두 추출" 또는 "Extract All"
→ 원하는 위치 선택 (예: C:\\Projects\\todo-app)
```

**macOS / Linux:**
```bash
unzip todo-app.zip
# 또는
unzip -d /path/to/project todo-app.zip
```

#### Step 1-3: 폴더 구조 확인
```
todo-app/
├── src/                    ✅ 소스 코드
├── gradle/                 ✅ Gradle 설정
├── build.gradle           ✅ 빌드 설정
├── README.md              ✅ 상세 문서
├── QUICKSTART.md          ✅ 빠른 시작
└── PROJECT_SUMMARY.md     ✅ 프로젝트 요약
```

### Phase 2: MySQL 설정 (10분)

#### Step 2-1: MySQL 서버 시작

**Windows (관리자 권한):**
```bash
net start MySQL80
```

**macOS:**
```bash
brew services start mysql
# 또는
mysql.server start
```

**Linux (Ubuntu):**
```bash
sudo systemctl start mysql
# 또는
sudo service mysql start
```

#### Step 2-2: MySQL 접속 확인

```bash
mysql -u root -p
# 프롬프트에서 MySQL 비밀번호 입력
```

#### Step 2-3: 데이터베이스 생성

MySQL 프롬프트에서 다음 명령 실행:

```sql
CREATE DATABASE todo_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

✅ 완료 메시지: `Query OK, 1 row affected`

#### Step 2-4: 데이터베이스 확인

```sql
SHOW DATABASES;
-- todo_db가 목록에 나타나야 함

EXIT;  -- MySQL 종료
```

### Phase 3: IntelliJ 설정 (10분)

#### Step 3-1: IntelliJ 프로젝트 열기

1. IntelliJ IDEA 실행
2. **File** → **Open** 클릭
3. 압축 해제한 `todo-app` 폴더 선택
4. **Open** 버튼 클릭

#### Step 3-2: Gradle 동기화

1. 프로젝트 로딩 대기 (화면 하단 진행률 표시)
2. "Gradle sync" 알림 화면 → "Reload" 클릭
3. Gradle 의존성 다운로드 (2~5분 소요)

📍 **완료 표시:**
- 우측 패널에 "Gradle" 탭 활성화
- 콘솔에 "Gradle build finished" 메시지

#### Step 3-3: Java 버전 확인

1. **File** → **Project Structure** → **Project**
2. **SDK**: JDK 17 이상 선택
3. **Language level**: 17 이상 선택
4. **OK** 클릭

### Phase 4: 데이터베이스 연결 설정 (5분)

#### Step 4-1: application.yml 파일 열기

프로젝트에서 다음 경로로 이동:
```
src/main/resources/application.yml
```

#### Step 4-2: MySQL 설정 확인

파일 내용:
```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/todo_db?serverTimezone=UTC&characterEncoding=UTF-8
    username: root
    password: root  # ← 여기 확인!
```

⚠️ **MySQL 비밀번호가 `root`가 아니면:**

```yaml
password: your_actual_password  # 실제 비밀번호로 변경
```

#### Step 4-3: 파일 저장

```
Ctrl+S (Windows) 또는 Cmd+S (Mac)
```

### Phase 5: 애플리케이션 실행 (5분)

#### Option A: IntelliJ에서 직접 실행 (추천)

1. 좌측 Project 패널에서 파일 찾기:
   ```
   src/main/java/com/example/todoapp/TodoAppApplication.java
   ```

2. 파일 열기 (더블 클릭)

3. 우측 상단의 **초록색 ▶️ Run 버튼** 클릭

4. "Run 'TodoAppApplication'" 선택

5. 콘솔 메시지 확인:
   ```
   Tomcat started on port(s): 8080 (http) with context path ''
   ```

#### Option B: 터미널에서 실행

```bash
cd todo-app
./gradlew bootRun
```

Windows:
```bash
cd todo-app
gradlew.bat bootRun
```

#### Option C: JAR 빌드 및 실행

```bash
# 빌드
cd todo-app
./gradlew build

# 실행
java -jar build/libs/todo-app-0.0.1-SNAPSHOT.jar
```

### Phase 6: 브라우저 접속 (1분)

브라우저 주소창에 입력:
```
http://localhost:8080
```

👁️ **예상 화면:**
- 할일 관리 앱 로고 표시
- 4가지 기능 소개 카드
- "로그인" / "회원가입" 버튼

---

## ✅ 첫 번째 사용

### Step 1: 회원가입

1. 홈페이지에서 **"회원가입"** 버튼 클릭
2. 다음 정보 입력:
   ```
   사용자명: testuser123
   이름: 테스트 사용자
   이메일: test@example.com
   비밀번호: Test1234!
   비밀번호 확인: Test1234!
   ```
3. **회원가입** 버튼 클릭
4. ✅ 성공 메시지 표시
5. 자동으로 로그인 페이지로 이동

### Step 2: 로그인

1. 로그인 페이지에서:
   ```
   사용자명: testuser123
   비밀번호: Test1234!
   ```
2. 체크박스: "로그인 유지" (선택사항)
3. **로그인** 버튼 클릭
4. ✅ 할일 목록 페이지로 이동

### Step 3: 할일 추가

1. "새로운 할일 추가" 섹션에서:
   ```
   제목: Spring Boot 학습
   설명: Spring Boot 3.0 기본 개념 학습
   마감날짜: 2025-02-15 18:00 (선택사항)
   공유: 체크 해제
   ```
2. **추가** 버튼 클릭
3. ✅ 할일이 "내 할일" 섹션에 추가됨

### Step 4: 할일 관리

- **완료 표시**: 할일 앞의 체크박스 클릭
- **수정**: "수정" 버튼 클릭
- **삭제**: "삭제" 버튼 클릭 (확인 필요)

### Step 5: 로그아웃

우측 상단 네비게이션 바에서 **"로그아웃"** 클릭

---

## 🚨 문제 해결

### 🔴 Error: "Cannot establish a database connection"

**원인:** MySQL 서버가 실행 중이지 않음

**해결책:**
```bash
# Windows
net start MySQL80

# macOS
brew services start mysql

# Linux
sudo systemctl start mysql
```

### 🔴 Error: "Access denied for user 'root'@'localhost'"

**원인:** MySQL 비밀번호 불일치

**해결책:**
1. 실제 MySQL 비밀번호 확인
2. `application.yml`의 `password` 값 변경
3. 파일 저장 후 애플리케이션 재시작

### 🔴 Error: "Port 8080 is already in use"

**원인:** 다른 애플리케이션이 8080 포트 사용 중

**해결책 1:** 포트 변경
```yaml
# application.yml
server:
  port: 9090  # 다른 포트로 변경
```

**해결책 2:** 기존 프로세스 종료
```bash
# Windows
lsof -i :8080  # 프로세스 찾기
kill -9 <PID>  # 프로세스 종료

# macOS/Linux
lsof -i :8080
kill -9 <PID>
```

### 🔴 Error: "Gradle sync failed"

**원인:** 네트워크 오류 또는 Java 버전 문제

**해결책:**
1. IntelliJ 재시작
2. **File** → **Invalidate Caches** → **Restart**
3. Java 버전 확인 (17 이상)

### 🔴 Slow Gradle Build

**원인:** 첫 실행 시 의존성 다운로드

**해결책:**
- 인터넷 연결 확인
- 첫 빌드는 5~10분 소요 (정상)
- 이후 실행은 빠름

---

## 📞 연락처 및 지원

### 일반적인 Q&A

**Q: 할일을 다른 사용자와 공유하려면?**
> A: 할일 생성/수정 시 "다른 사용자와 공유" 체크박스를 선택하세요.

**Q: 로그인 없이 할일을 볼 수 있나요?**
> A: 아니오. 보안상 이유로 로그인이 필수입니다.

**Q: 할일을 내보낼 수 있나요?**
> A: 현재 버전에서는 미지원입니다. (향후 추가 예정)

**Q: 서버를 중지하려면?**
> IntelliJ에서 콘솔 우상단의 빨간색 🛑 버튼 클릭 또는 `Ctrl+C`

---

## 🎓 다음 단계

애플리케이션 실행에 성공했다면:

1. **README.md** 읽기
   - 상세한 기술 문서
   - 프로젝트 구조 이해

2. **PROJECT_SUMMARY.md** 읽기
   - 프로젝트 완성도 확인
   - 기술 스택 이해

3. **소스 코드 탐색**
   - Controller 계층 분석
   - Service 계층 분석
   - Domain/Entity 이해

4. **기능 확장**
   - 새로운 기능 추가
   - 데이터베이스 스키마 확장
   - UI/UX 개선

---

## 📊 성능 최적화 팁

### 개발 중 최적화
```yaml
# application.yml
spring:
  jpa:
    show-sql: false  # 많은 쿼리 로그는 성능 저하
    properties:
      hibernate:
        format_sql: false
```

### 대량 데이터 처리
- 페이지네이션 구현
- 캐싱 추가
- 데이터베이스 인덱싱

---

## 💾 데이터 백업

MySQL 데이터 내보내기:
```bash
mysqldump -u root -p todo_db > backup.sql
```

데이터 복원:
```bash
mysql -u root -p todo_db < backup.sql
```

---

## 🔒 보안 체크리스트

프로덕션 배포 전 확인:
- [ ] MySQL 기본 비밀번호 변경
- [ ] application.yml의 민감 정보 환경 변수로 변경
- [ ] HTTPS 적용 (배포 환경)
- [ ] SQL Injection 방지 (JPA 사용으로 기본 방지)
- [ ] CSRF 토큰 활성화 (기본 활성화)

---

## 📱 모바일 접속

응답형 디자인으로 모든 기기에서 작동:
```
http://localhost:8080
```

- ✅ Desktop (1920x1080 이상)
- ✅ Tablet (768px 이상)
- ✅ Mobile (320px 이상)

---

## 🎊 완료!

축하합니다! 완전한 Spring Boot 웹 애플리케이션을 설치했습니다.

다음 사항을 확인하세요:
1. ✅ MySQL이 실행 중
2. ✅ 애플리케이션이 포트 8080에서 실행 중
3. ✅ http://localhost:8080 접속 가능
4. ✅ 회원가입/로그인 가능
5. ✅ 할일 CRUD 작동

### 문제가 있으면:
1. 이 문서의 "문제 해결" 섹션 확인
2. README.md의 FAQ 확인
3. 콘솔 로그 확인

### 다음은?
- 코드 리뷰 및 이해
- 새로운 기능 추가
- 배포 준비

**Happy Coding! 🚀**

---

**작성일**: 2025-01-15  
**Spring Boot 버전**: 3.2.0  
**Java 버전**: 17+  
**상태**: ✅ 테스트 완료
'''

guide_path = f"{project_root}/INSTALL_GUIDE.md"
with open(guide_path, "w", encoding="utf-8") as f:
    f.write(install_guide)

print("✓ INSTALL_GUIDE.md (설치 가이드) 작성 완료")
