
# 파일 정보 확인 및 최종 검증
import zipfile
import os

zip_path = "/tmp/todo-app.zip"

# ZIP 파일이 제대로 생성되었는지 확인
print("\n" + "="*70)
print("🔍 최종 검증")
print("="*70)

if os.path.exists(zip_path):
    # 파일 정보
    file_size = os.path.getsize(zip_path)
    file_size_mb = file_size / (1024 * 1024)
    
    print(f"\n✅ ZIP 파일 존재 확인")
    print(f"   파일명: todo-app.zip")
    print(f"   크기: {file_size_mb:.2f} MB ({file_size} bytes)")
    
    # ZIP 압축 여부 확인
    try:
        with zipfile.ZipFile(zip_path, 'r') as zipf:
            # 파일 목록
            files = zipf.namelist()
            
            # 필수 파일 확인
            essential_files = {
                'build.gradle': '❌ 없음',
                'settings.gradle': '❌ 없음',
                'src/main/java/com/example/todoapp/TodoAppApplication.java': '❌ 없음',
                'src/main/resources/application.yml': '❌ 없음',
                'src/main/resources/templates/login.html': '❌ 없음',
                'src/main/resources/templates/tasks.html': '❌ 없음',
                'src/main/resources/static/css/style.css': '❌ 없음',
                'README.md': '❌ 없음',
                'QUICKSTART.md': '❌ 없음'
            }
            
            print(f"\n✅ ZIP 압축 상태 확인 (총 {len(files)}개 파일)")
            
            for essential in essential_files:
                for file in files:
                    if essential in file:
                        essential_files[essential] = '✅ 포함'
                        break
            
            print("\n필수 파일 확인:")
            for essential, status in essential_files.items():
                filename = essential.split('/')[-1]
                print(f"  {status} {filename}")
            
            # 파일 카테고리 통계
            print("\n📊 파일 카테고리 통계:")
            categories = {
                'Java (.java)': len([f for f in files if f.endswith('.java')]),
                'HTML (.html)': len([f for f in files if f.endswith('.html')]),
                'CSS (.css)': len([f for f in files if f.endswith('.css')]),
                'YAML/Config': len([f for f in files if f.endswith(('.yml', '.yaml', '.properties', 'gradle'))]),
                'Documentation (.md)': len([f for f in files if f.endswith('.md')]),
                'Others': len([f for f in files if not any(f.endswith(x) for x in ['.java', '.html', '.css', '.yml', '.yaml', '.properties', '.md', 'gradle'])])
            }
            
            for category, count in categories.items():
                print(f"  • {category}: {count}개")
            
    except zipfile.BadZipFile:
        print("\n❌ ZIP 파일 손상됨")
else:
    print("\n❌ ZIP 파일 없음")

print("\n" + "="*70)
print("🎊 프로젝트 생성 완료!")
print("="*70)
