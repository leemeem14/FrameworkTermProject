
# Main Application Class

# TodoAppApplication.java
todo_app_main = '''package com.example.todoapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoAppApplication.class, args);
	}

}
'''

with open(f"{project_root}/src/main/java/com/example/todoapp/TodoAppApplication.java", "w") as f:
    f.write(todo_app_main)

print("✓ TodoAppApplication.java 작성 완료")
