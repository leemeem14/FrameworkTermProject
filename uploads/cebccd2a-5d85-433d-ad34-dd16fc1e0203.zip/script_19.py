
# 사용 설명서 생성
guide = '''# 📚 할일 관리 앱 - 사용 설명서

## 🚀 빠른 시작 가이드

### 1️⃣ 프로젝트 준비

#### 1-1. ZIP 파일 압축 해제
```bash
# Windows
압축 풀기 마우스 우클릭 → "모두 추출"

# macOS / Linux
unzip todo-app.zip
```

#### 1-2. IntelliJ에서 프로젝트 열기
- IntelliJ IDEA 실행
- File → Open
- 압축 해제한 `todo-app` 폴더 선택
- Gradle 동기화 대기 (자동 진행, 2~5분 소요)

### 2️⃣ MySQL 설정

#### 2-1. MySQL 설치 및 실행

**Windows:**
1. MySQL Community Server 8.0 이상 설치
2. MySQL 서버 시작:
   ```bash
   net start MySQL80
   ```

**macOS:**
```bash
brew install mysql
brew services start mysql
```

**Linux (Ubuntu):**
```bash
sudo apt-get install mysql-server
sudo systemctl start mysql
```

#### 2-2. 데이터베이스 생성
```bash
# MySQL 명령줄 접속
mysql -u root -p

# MySQL 프롬프트에서 실행
CREATE DATABASE todo_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
EXIT;
```

#### 2-3. 기본 설정 확인
`src/main/resources/application.yml` 파일 확인:

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/todo_db?serverTimezone=UTC&characterEncoding=UTF-8
    username: root
    password: root  # ⚠️ 자신의 MySQL 비밀번호로 변경
```

❌ MySQL 비밀번호가 `root`가 아니면:
- `password: root` 부분을 실제 비밀번호로 변경

### 3️⃣ 애플리케이션 실행

**방법 A: IntelliJ에서 직접 실행 (추천)**
1. 좌측 Project 패널에서 `TodoAppApplication.java` 파일 찾기
2. 파일 우측 상단의 녹색 ▶️ 버튼 클릭
3. "Run 'TodoAppApplication'" 선택
4. 콘솔에서 "Tomcat started on port 8080" 메시지 확인

**방법 B: 터미널에서 실행**
```bash
cd todo-app
./gradlew bootRun
```

**방법 C: JAR 파일로 빌드 및 실행**
```bash
cd todo-app
./gradlew build
java -jar build/libs/todo-app-0.0.1-SNAPSHOT.jar
```

### 4️⃣ 애플리케이션 접속

브라우저에서 다음 주소로 접속:
```
http://localhost:8080
```

👉 홈페이지가 표시되면 성공!

---

## 📖 사용 방법

### 1. 회원가입

#### 회원가입 페이지 이동
1. 홈페이지에서 "회원가입" 버튼 클릭
2. 또는 http://localhost:8080/auth/signup 직접 접속

#### 필수 정보 입력
| 항목 | 설명 | 요구사항 |
|------|------|---------|
| 사용자명 | 로그인할 때 사용 | 3~20자, 영문/숫자 |
| 이름 | 실명 또는 닉네임 | 1자 이상 |
| 이메일 | 유효한 이메일 주소 | example@email.com 형식 |
| 비밀번호 | 로그인 비밀번호 | 6자 이상 |
| 비밀번호 확인 | 비밀번호 확인 | 위와 동일해야 함 |

#### 예시
```
사용자명: john_doe
이름: 홍길동
이메일: john@example.com
비밀번호: myPassword123
비밀번호 확인: myPassword123
```

### 2. 로그인

1. 홈페이지에서 "로그인" 버튼 클릭
2. 사용자명과 비밀번호 입력
3. "로그입 유지" 체크박스 (선택사항)
4. 로그인 버튼 클릭

✅ 로그인 성공 시 할일 목록 페이지로 이동

### 3. 할일 관리

#### ✏️ 할일 추가
1. "새로운 할일 추가" 섹션에서:
   - **할일 제목**: 필수 입력 (예: "프로젝트 완성")
   - **설명**: 선택사항 (예: "Spring Boot 프로젝트 완성")
   - **마감날짜**: 선택사항 (예: 2025-01-15 18:00)
   - **공유**: 체크하면 다른 사용자와 공유 가능
2. "추가" 버튼 클릭

#### ✅ 할일 완료 표시
- 할일 앞의 체크박스를 클릭하면 완료 상태 변경
- 완료된 할일은 회색으로 표시되고 취소선 추가

#### ✏️ 할일 수정
1. 할일 카드의 "수정" 버튼 클릭
2. 필요한 정보 수정
3. "저장" 버튼 클릭

#### 🗑️ 할일 삭제
1. 할일 카드의 "삭제" 버튼 클릭
2. 확인 창에서 "확인" 클릭
3. ⚠️ 삭제된 할일은 복구할 수 없습니다

#### 🔄 할일 공유
1. 할일 추가/수정 시 "다른 사용자와 공유" 체크
2. 해당 사용자가 로그인하면 "공유된 할일" 섹션에서 확인 가능
3. 공유된 할일은 편집 불가 (읽기 전용)

### 4. 로그아웃

1. 우측 상단 네비게이션 바에서 "로그아웃" 버튼 클릭
2. 로그인 페이지로 리다이렉트

---

## ⚙️ 설정 변경

### MySQL 비밀번호 변경
```yaml
# src/main/resources/application.yml

spring:
  datasource:
    password: 새_비밀번호  # 이 부분 변경
```

### 포트 번호 변경 (기본값: 8080)
```yaml
server:
  port: 9090  # 원하는 포트 번호로 변경
```

### 데이터베이스 자동 생성/업데이트 설정
```yaml
spring:
  jpa:
    hibernate:
      ddl-auto: update  # create: 재생성, update: 업데이트, validate: 검증만
```

---

## 🐛 문제 해결

### ❌ "java.sql.SQLException: Cannot get a connection"
**원인**: MySQL 서버 미실행 또는 연결 정보 오류

**해결책**:
1. MySQL 서버 실행 상태 확인
```bash
# Windows
net start MySQL80

# macOS
brew services start mysql

# Linux
sudo systemctl start mysql
```
2. `application.yml`의 username, password 확인
3. `todo_db` 데이터베이스 생성 확인

### ❌ "Port 8080 is already in use"
**원인**: 다른 애플리케이션이 8080 포트 사용 중

**해결책**:
1. `application.yml`에서 포트 변경:
```yaml
server:
  port: 9090
```
2. 또는 기존 포트의 프로세스 종료

### ❌ Gradle 동기화 실패
**원인**: 네트워크 오류 또는 Java 버전 오류

**해결책**:
1. IntelliJ → File → Invalidate Caches → Restart
2. Gradle 재동기화 (View → Tool Windows → Gradle → 새로고침)
3. Java 버전 확인 (17 이상 필요):
```bash
java -version
```

### ❌ "404 Not Found" 오류
**원인**: 잘못된 URL 접속

**정확한 URL**:
- 홈: http://localhost:8080
- 로그인: http://localhost:8080/auth/login
- 회원가입: http://localhost:8080/auth/signup
- 할일 목록: http://localhost:8080/tasks

---

## 📋 기본 테스트 시나리오

### 테스트 계정 생성 및 사용

#### 1단계: 회원가입
1. http://localhost:8080/auth/signup 접속
2. 다음 정보 입력:
   ```
   사용자명: testuser
   이름: 테스트 사용자
   이메일: test@example.com
   비밀번호: test1234
   ```
3. 회원가입 완료

#### 2단계: 로그인
1. http://localhost:8080/auth/login 접속
2. 사용자명: testuser, 비밀번호: test1234 입력
3. 로그인 성공 → 할일 목록 페이지로 이동

#### 3단계: 할일 추가
1. "새로운 할일 추가" 섹션에서:
   ```
   제목: Spring Boot 학습
   설명: Spring Boot 3.0 기능 학습
   마감날짜: 2025-02-28 17:00
   ```
2. "추가" 버튼 클릭
3. "내 할일" 섹션에 새로운 항목 추가됨

#### 4단계: 할일 관리
1. 체크박스 클릭하여 완료 표시
2. "수정" 버튼으로 내용 수정
3. "삭제" 버튼으로 할일 삭제

---

## 💡 팁과 요령

### ✨ 효율적인 할일 관리
1. **마감날짜 설정**: 중요한 할일에는 마감날짜 설정
2. **설명 활용**: 복잡한 할일은 설명에 세부사항 기록
3. **공유 기능**: 팀 프로젝트는 동료와 공유

### 🔒 보안 팁
1. **강력한 비밀번호**: 8자 이상, 대소문자+숫자+특수문자 혼합
2. **"로그인 유지" 사용 주의**: 공용 컴퓨터에서는 체크하지 않기
3. **정기적 로그아웃**: 사용 후 항상 로그아웃

### ⚡ 성능 팁
1. 수백 개 이상의 할일 작성 시 로딩 속도 저하 가능
2. 주기적으로 완료된 할일 정리

---

## 📞 지원

문제 발생 시:
1. 위의 "문제 해결" 섹션 참조
2. MySQL 로그 확인:
```bash
# Windows
C:\\ProgramData\\MySQL\\MySQL Server 8.0\\Data\\[hostname].err

# macOS
/usr/local/var/mysql/[hostname].err
```
3. Spring Boot 콘솔 로그 확인

---

## 🎓 학습 포인트

이 프로젝트에서 학습할 수 있는 기술:

- ✅ Spring Boot 애플리케이션 구조
- ✅ Spring Data JPA와 Hibernate ORM
- ✅ Spring Security를 이용한 인증/권한
- ✅ Thymeleaf 템플릿 엔진
- ✅ MySQL 데이터베이스 연동
- ✅ RESTful 컨트롤러 설계
- ✅ 엔티티 관계 설정 (One-to-Many, Many-to-Many)
- ✅ HTML/CSS 웹 UI 구현

---

**Happy Coding! 🚀**
'''

guide_path = f"{project_root}/QUICKSTART.md"
with open(guide_path, "w", encoding="utf-8") as f:
    f.write(guide)

print("✓ QUICKSTART.md (사용 설명서) 작성 완료")
print(f"경로: {guide_path}")
