
# 최종 ZIP 파일 생성 (QUICKSTART 포함)
import zipfile

# 기존 ZIP 파일 삭제 후 재생성
zip_path = "/tmp/todo-app.zip"
project_root = "/tmp/todo-app"

def zipdir(path, ziph):
    """재귀적으로 디렉토리를 zip 파일에 추가"""
    for root, dirs, files in os.walk(path):
        for file in files:
            file_path = os.path.join(root, file)
            arcname = os.path.relpath(file_path, os.path.dirname(path))
            ziph.write(file_path, arcname)

# 기존 ZIP 삭제
if os.path.exists(zip_path):
    os.remove(zip_path)

# 새 ZIP 파일 생성
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    zipdir(project_root, zipf)

# 파일 크기 확인
zip_size = os.path.getsize(zip_path) / (1024 * 1024)

print("=" * 70)
print("📦 최종 ZIP 파일 생성 완료!")
print("=" * 70)
print(f"파일 경로: {zip_path}")
print(f"파일 크기: {zip_size:.2f} MB")
print("=" * 70)

# ZIP 파일 내용 확인
with zipfile.ZipFile(zip_path, 'r') as zipf:
    file_list = zipf.namelist()
    print(f"\n✅ 총 {len(file_list)}개 파일 포함")
    print("\n📋 주요 파일 목록:")
    
    # 주요 파일 카테고리별 분류
    categories = {
        "📄 설정 파일": [],
        "☕ Java 클래스": [],
        "🌐 HTML 템플릿": [],
        "🎨 CSS 스타일": [],
        "⚙️ Gradle 설정": [],
        "📚 문서": []
    }
    
    for file in file_list:
        if file.endswith('.yaml') or file.endswith('.yml') or file.endswith('.properties'):
            categories["📄 설정 파일"].append(file)
        elif file.endswith('.java'):
            categories["☕ Java 클래스"].append(file)
        elif file.endswith('.html'):
            categories["🌐 HTML 템플릿"].append(file)
        elif file.endswith('.css'):
            categories["🎨 CSS 스타일"].append(file)
        elif 'gradle' in file:
            categories["⚙️ Gradle 설정"].append(file)
        elif file.endswith('.md'):
            categories["📚 문서"].append(file)
    
    for category, files in categories.items():
        if files:
            print(f"\n{category} ({len(files)}개)")
            for file in files[:3]:
                print(f"  └─ {file}")
            if len(files) > 3:
                print(f"  └─ ... {len(files) - 3}개 더")

print("\n" + "=" * 70)
