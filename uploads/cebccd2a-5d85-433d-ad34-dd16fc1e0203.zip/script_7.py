
# Controller 클래스들

# 1. AuthController.java
auth_controller = '''package com.example.todoapp.controller;

import com.example.todoapp.domain.User;
import com.example.todoapp.dto.SignupRequest;
import com.example.todoapp.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/auth")
@RequiredArgsConstructor
@Slf4j
public class AuthController {
    
    private final UserService userService;
    
    @GetMapping("/login")
    public String loginPage(Authentication authentication) {
        if (authentication != null && authentication.isAuthenticated()) {
            return "redirect:/tasks";
        }
        return "login";
    }
    
    @GetMapping("/signup")
    public String signupPage(Model model, Authentication authentication) {
        if (authentication != null && authentication.isAuthenticated()) {
            return "redirect:/tasks";
        }
        model.addAttribute("signupRequest", new SignupRequest());
        return "signup";
    }
    
    @PostMapping("/signup")
    public String signup(@Valid SignupRequest request, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "signup";
        }
        
        try {
            userService.signup(request);
            return "redirect:/auth/login?success";
        } catch (IllegalArgumentException e) {
            model.addAttribute("error", e.getMessage());
            return "signup";
        }
    }
}
'''

# 2. TaskController.java
task_controller = '''package com.example.todoapp.controller;

import com.example.todoapp.domain.Task;
import com.example.todoapp.domain.User;
import com.example.todoapp.dto.TaskRequest;
import com.example.todoapp.service.TaskService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/tasks")
@RequiredArgsConstructor
@Slf4j
public class TaskController {
    
    private final TaskService taskService;
    
    @GetMapping
    public String listTasks(Authentication authentication, Model model) {
        User user = (User) authentication.getPrincipal();
        
        List<Task> myTasks = taskService.findMyTasks(user);
        List<Task> sharedTasks = taskService.findSharedWithMe(user);
        
        model.addAttribute("myTasks", myTasks);
        model.addAttribute("sharedTasks", sharedTasks);
        model.addAttribute("user", user);
        model.addAttribute("taskRequest", new TaskRequest());
        
        return "tasks";
    }
    
    @PostMapping
    public String createTask(@Valid TaskRequest request, BindingResult result, 
                           Authentication authentication, RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            redirectAttributes.addFlashAttribute("error", "입력값을 확인해주세요");
            return "redirect:/tasks";
        }
        
        User user = (User) authentication.getPrincipal();
        
        try {
            taskService.createTask(request, user);
            redirectAttributes.addFlashAttribute("success", "할일이 생성되었습니다");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "할일 생성에 실패했습니다");
        }
        
        return "redirect:/tasks";
    }
    
    @GetMapping("/{id}/edit")
    public String editTaskForm(@PathVariable Long id, Authentication authentication, Model model) {
        User user = (User) authentication.getPrincipal();
        Task task = taskService.findTaskById(id, user)
                .orElseThrow(() -> new IllegalArgumentException("할일을 찾을 수 없습니다"));
        
        TaskRequest request = new TaskRequest();
        request.setTitle(task.getTitle());
        request.setDescription(task.getDescription());
        request.setDueDate(task.getDueDate());
        request.setIsShared(task.getIsShared());
        
        model.addAttribute("task", task);
        model.addAttribute("taskRequest", request);
        return "task-edit";
    }
    
    @PostMapping("/{id}/update")
    public String updateTask(@PathVariable Long id, @Valid TaskRequest request, 
                           BindingResult result, Authentication authentication, 
                           RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            return "redirect:/tasks/" + id + "/edit";
        }
        
        User user = (User) authentication.getPrincipal();
        
        try {
            taskService.updateTask(id, request, user);
            redirectAttributes.addFlashAttribute("success", "할일이 수정되었습니다");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "할일 수정에 실패했습니다");
        }
        
        return "redirect:/tasks";
    }
    
    @PostMapping("/{id}/delete")
    public String deleteTask(@PathVariable Long id, Authentication authentication, 
                           RedirectAttributes redirectAttributes) {
        User user = (User) authentication.getPrincipal();
        
        try {
            taskService.deleteTask(id, user);
            redirectAttributes.addFlashAttribute("success", "할일이 삭제되었습니다");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "할일 삭제에 실패했습니다");
        }
        
        return "redirect:/tasks";
    }
    
    @PostMapping("/{id}/toggle")
    public String toggleTaskCompletion(@PathVariable Long id, Authentication authentication, 
                                     RedirectAttributes redirectAttributes) {
        User user = (User) authentication.getPrincipal();
        
        try {
            taskService.toggleTaskCompletion(id, user);
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "할일 상태 변경에 실패했습니다");
        }
        
        return "redirect:/tasks";
    }
}
'''

# 파일 작성
with open(f"{project_root}/src/main/java/com/example/todoapp/controller/AuthController.java", "w") as f:
    f.write(auth_controller)
    
with open(f"{project_root}/src/main/java/com/example/todoapp/controller/TaskController.java", "w") as f:
    f.write(task_controller)

print("✓ AuthController.java 작성 완료")
print("✓ TaskController.java 작성 완료")
