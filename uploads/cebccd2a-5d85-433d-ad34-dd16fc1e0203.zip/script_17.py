
# 프로젝트 완성도 확인
import os

print("=" * 60)
print("프로젝트 구조 확인")
print("=" * 60)

total_files = 0
total_dirs = 0

for root, dirs, files in os.walk(project_root):
    total_dirs += len(dirs)
    total_files += len(files)
    
    # 상대 경로 표시
    level = root.replace(project_root, '').count(os.sep)
    indent = ' ' * 2 * level
    rel_path = os.path.basename(root)
    if level == 0:
        rel_path = 'todo-app/'
    print(f'{indent}{rel_path}/')
    
    # 파일 목록 (최대 5개까지만)
    for file in files[:5]:
        print(f'{indent}  - {file}')
    if len(files) > 5:
        print(f'{indent}  ... ({len(files) - 5} more files)')

print("\n" + "=" * 60)
print(f"총 디렉토리: {total_dirs}")
print(f"총 파일: {total_files}")
print("=" * 60)
