
# Gradle wrapper 파일들 생성

# gradle-wrapper.properties
gradle_wrapper_props = '''distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https://services.gradle.org/distributions/gradle-8.4-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
'''

# gradlew (간단화된 버전)
gradlew_script = '''#!/bin/sh

# Gradle wrapper script
GRADLE_USER_HOME="${GRADLE_USER_HOME:-$HOME/.gradle}"

exec java -jar "$GRADLE_USER_HOME/wrapper/dists/gradle-8.4-bin/gradle-8.4/lib/gradle-base-services-groovy-8.4.jar" "$@"
'''

with open(f"{project_root}/gradle/wrapper/gradle-wrapper.properties", "w") as f:
    f.write(gradle_wrapper_props)
    
with open(f"{project_root}/gradlew", "w") as f:
    f.write(gradlew_script)

print("✓ gradle/wrapper/gradle-wrapper.properties 작성 완료")
print("✓ gradlew 작성 완료")
